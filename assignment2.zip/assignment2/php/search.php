<!DOCTYPE html> 
<html> 
  <head>

<link rel='stylesheet' href='css/styles.css'>
<script type="text/javascript" src="js/script.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/jquery-3.3.1.js"></script>	
	<script src="js/index.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
  </head>

<?php
ini_set('display_startup_errors', 1);	

	session_start();
	require'config.php';
?> 

<body>
<?php
if(isset($_POST['search']))
{
    	$query = $_POST['query'];
   	$min_length = 1;

	if(strlen($query) >= $min_length){ // if query length is more or equal minimum length then
       		$query = htmlspecialchars($query);
		//$query = mysqli_real_escape_string($query);
        	$raw_results = mysqli_query($con, "SELECT ItemName, Discription, price FROM Items  WHERE  (ItemID LIKE '%$query%') OR (ItemName LIKE '%$query%') OR (Discription LIKE '%$query%') OR (Price LIKE '%$query%')");
// or die(mysql_error());
        // * means that it selects all fields, you can also write: `id`, `title`, `text`
        // articles is the name of our table
         
        // '%$query%' is what we're looking for, % means anything, for example if $query is Hello
        // it will match "hello", "Hello man", "gogohello", if you want exact match use `title`='$query'
        // or if you want to match just full word so "gogohello" is out use '% $query %' ...OR ... '$query %' ... OR ... '% $query'
         
       		 if(mysqli_num_rows($raw_results) > 0){ // if one or more rows are returned do following
            		while($results = mysqli_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
                		//$result = "<div class='column'> <div class='card' style='width: 18rem;'> <div class='card-body'> <h5 class='card-title'> ". $results["ItemName"].
				//" <p class='card-text'>". $results["Discription"]. "</p> <p><a href='#i5'><button>View Item</button></a></p> </div> </div> </div>";
				//echo ($result);	
echo "<div class='column'> <div class='card' style='width: 18rem;'> <div class='card-body'> <h5 class='card-title'> ". $results["ItemName"].
" <p class='card-text'>". $results["Discription"]. "<h4>Price:".$result["price"]."</h4></p><p><a href='../index.php#buy'><button>Buy Item</button></a></p> </div> </div> </div>";
		
			//echo "<br> ItemName: ". $result["ItemName"]. " - discription: ". $result["Discription"]. "<br>";

			//	header("Location: index.html?result=".$result);

		}
                // posts results gotten from database(title and text) you can also show id ($results['id'])
            	 }
             
        }
        else{ // if there is no matching rows do following
            echo "No results found!";
        }
}
else{ // if query length is less than minimum
    echo "Minimum length is ";
} 

?>

<article id='buy' hidden='hidden'>
<h4>Thanks for buying!</h4>
</article>


</body>
</html>

