


<?php

 	session_start();
        require'config.php';

	if(isset($_POST['login']))
	{
		 $username= $_POST['username'];
	        $password= $_POST['password'];

		$query="select*from UserInfo WHERE username='$username' AND password='$password'";
		 $query_run = mysqli_query($con,$query);

		if(mysqli_num_rows($query_run)>0)
		{
			//valid

			$_SESSION['username']=$username;
			$_SESSION['password']=$password;

		}
		else
		{
			//invalid
			echo'<script type="text/javascript"> alert("Invalid Username or Password")</script>';
		}


	}
	else{
              echo'<script type="text/javascript"> alert("Username or Password may not match.. Try again")</script>';

	}

?>

<div id="id03" class="homeModal" >
            <form id="home" class="homePage-content animate" action="#" method="post">

                <div class="imgcontainer">
                  <span onclick="document.getElementById('id03').style.display='none'" class="close" title="Close Modal">&times;</span>
                  <h2>Home Page</h2>
                  <h3> Welcome <?php echo $_SESSION['username'] ?> </h3>
                  <img src="../img/anonymous.jpeg" alt="anonymous" class="anonymous">
                </div>


                <div class="container" style="background-color:#f1f1f1">
                  <input type="button" name="logout" class="logoutbtn" value="Logout"/>

                </div>
              </form>
 </div>

<article id='profile' hidden='hidden'>
	  <div class="profilecontainer">
        <h1>Personal Profile</h1>
        <h4>Name:</h4>
        <p>name here</p>
        <h4>ID:</h4>
	<p><?php echo $_SESSION['username'] ?></p>
	<h4>Password:</h4>
	<p><?php echo $_SESSION['password'] ?></p>
	<h4>Email:</h4>
	<p>email here</p>
        <h4>Address</h4>
        <p>address here</p>
      </div>
</article>




