<?php 

echo'<script type="text/javascript"> alert("Sucessfully login")</script>';

  echo " hello You win";
 ?>
